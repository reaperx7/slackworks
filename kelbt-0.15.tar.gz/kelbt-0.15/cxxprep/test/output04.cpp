
void $[di main]({int $[di argc], char $<*>[di argv][[]]})
{
	int $[di i] = --helloNed(1.1, i, i++);
	+ ++foobar++();
}



class C {

};

void main(int argc, char *argv[])
{
	C (*foo)(int);
	C(foo, bar)(int(1));
	int i = sizeof( int() );
	C (*foo);
	int i = int(1);
	int i = (int)(1);
	int i = (int*)(1);
	int i = (int())(1);

	int i = 1 + 2 + int(1*3) + typeid(int (a)*1*int((*a),1));
}

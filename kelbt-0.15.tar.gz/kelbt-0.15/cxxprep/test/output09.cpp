
void $[di main]({int $[di argc], char $<*>[di argv][[]]})
{
	i = 0 + 1u + 10lL + 111Lu;
	o = 00 + 0123 + 01lL * 0LL;
	h = 0x33ABCDEFabcdefll + 0x0 + 0x0ll / 0x0UL;
	b = true - +(+false) * true++;
}

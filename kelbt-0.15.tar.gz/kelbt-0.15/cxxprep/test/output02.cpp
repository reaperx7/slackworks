

template <{class T}> class [cn C] 
{
};

class [cn C]<|int|>;

class [cn C]<|int|>
{
};

void $[di f]({ int $(|<*>[di f]|)[[2]]({int}) });

class [cn D]
{
	[cn D] $<*>[di foo];
};
struct [cn E]
{
	class [cn D] {
		void $[di e]({[cn E] $[di i]});
		$[di D]({int $[di i]});
		$[di D]({[cn D] $[di i]});
		$[di D]({[cn D] $[di D]});
		$~[di D]({});
		virtual $~[di D]({});
//		template <class> class C;
		class [cn C]<|int <*>|> {
			$[cn E]::[di alsdfj];			
		};
		class [cn D] {};

		class [cn F] {
			$[cn E]::[cn D]::[cn F]::[di F]({int $[di i], const [cn F] $<*>[di k]});
		};
	};


	void $[di length]({}) const {}
};


class [cn Base]
{
public:~
	virtual void $[di foo]({});
};

class [cn SubClass] 
{

};

int $[di main]({})
{
	foo = [cn E]::[cn D](bar);
	bar = foo(88.8);
}


class C
{
    class C
    {
        C() {}
    };
};

int main()
{
    i = C::C();
}


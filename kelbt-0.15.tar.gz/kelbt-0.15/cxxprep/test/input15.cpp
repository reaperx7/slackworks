
class C;

class C::D;

class C
{
	D foo();
};

int main() 
{
	class D;
	C *c(int i);
	D *d();
	int i = foo->C::poo( a[22][233]++ - ~11 || a ? c.hi(1-1):33);
}
